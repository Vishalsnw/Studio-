package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = VibrantPrimaryContainer, // Swap for high contrast in dark mode
  onPrimary = VibrantOnPrimaryContainer,
  primaryContainer = VibrantPrimary,
  onPrimaryContainer = VibrantOnPrimary,
  secondary = VibrantSecondaryContainer,
  onSecondary = VibrantOnSecondaryContainer,
  background = VibrantOnBackground, // Darker slate
  onBackground = VibrantBackground,
  surface = Color(0xFF111318),
  onSurface = Color(0xFFE2E2E6),
  outline = VibrantOutlineVariant,
  outlineVariant = VibrantOutline
)

private val LightColorScheme = lightColorScheme(
  primary = VibrantPrimary,
  onPrimary = VibrantOnPrimary,
  primaryContainer = VibrantPrimaryContainer,
  onPrimaryContainer = VibrantOnPrimaryContainer,
  secondary = VibrantSecondary,
  onSecondary = VibrantOnSecondary,
  secondaryContainer = VibrantSecondaryContainer,
  onSecondaryContainer = VibrantOnSecondaryContainer,
  background = VibrantBackground,
  onBackground = VibrantOnBackground,
  surface = VibrantSurface,
  onSurface = VibrantOnSurface,
  surfaceVariant = VibrantSurfaceVariant,
  onSurfaceVariant = VibrantOnSurfaceVariant,
  outline = VibrantOutline,
  outlineVariant = VibrantOutlineVariant
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  // We disable it by default to guarantee our custom "Vibrant Palette" is shown.
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
