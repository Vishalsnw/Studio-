package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Palette theme color variables
val VibrantPrimary = Color(0xFF0061A4)
val VibrantOnPrimary = Color(0xFFFFFFFF)
val VibrantPrimaryContainer = Color(0xFFD1E4FF)
val VibrantOnPrimaryContainer = Color(0xFF001D36)

val VibrantSecondary = Color(0xFF386663)
val VibrantOnSecondary = Color(0xFFFFFFFF)
val VibrantSecondaryContainer = Color(0xFFDCECE9)
val VibrantOnSecondaryContainer = Color(0xFF00201E)

val VibrantBackground = Color(0xFFF7F9FF)
val VibrantOnBackground = Color(0xFF191C1E)

val VibrantSurface = Color(0xFFF3F4F9)
val VibrantOnSurface = Color(0xFF191C1E)
val VibrantSurfaceVariant = Color(0xFFE1E2EC)
val VibrantOnSurfaceVariant = Color(0xFF44474F)

val VibrantOutline = Color(0xFF74777F)
val VibrantOutlineVariant = Color(0xFFC4C7CF)
