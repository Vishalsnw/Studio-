package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        HelloWorldApp()
      }
    }
  }
}

// Data class representing an elegant greeting
data class GreetingLanguage(
  val template: String, // e.g. "Bonjour, %s!"
  val language: String, // e.g. "French"
  val nativeName: String // e.g. "Français"
)

// Data class representing a cultural fun fact
data class GreetingFact(
  val language: String,
  val fact: String,
  val origin: String
)

val INITIAL_GREETINGS = listOf(
  GreetingLanguage("Hello, %s!", "English", "English"),
  GreetingLanguage("Bonjour, %s!", "French", "Français"),
  GreetingLanguage("Hola, %s!", "Spanish", "Español"),
  GreetingLanguage("Ciao, %s!", "Italian", "Italiano"),
  GreetingLanguage("Hallo, %s!", "German", "Deutsch"),
  GreetingLanguage("Olá, %s!", "Portuguese", "Português"),
  GreetingLanguage("Namaste, %s!", "Hindi", "हिन्दी"),
  GreetingLanguage("Konnichiwa, %s!", "Japanese", "日本語"),
  GreetingLanguage("Annyeong, %s!", "Korean", "한국어"),
  GreetingLanguage("Ni Hao, %s!", "Chinese", "中文")
)

val GREETING_FACTS = listOf(
  GreetingFact("Hindi", "\"Namaste\" literally means \"I bow to the divine in you,\" representing deep spiritual respect.", "India"),
  GreetingFact("Japanese", "\"Konnichiwa\" was historically the beginning of a full sentence wishing you a good day.", "Japan"),
  GreetingFact("Italian", "\"Ciao\" is derived from a Venetian greeting meaning \"I am your slave\" (at your service).", "Italy"),
  GreetingFact("Spanish", "\"Hola\" comes from Arabic \"Wa-Allah,\" invoking the name of God in friendly greeting.", "Spain"),
  GreetingFact("French", "\"Bonjour\" combines \"bon\" (good) and \"jour\" (day), a direct wish of warmth.", "France"),
  GreetingFact("Portuguese", "\"Olá\" dates back to old maritime greetings signaling across incoming ships.", "Portugal")
)

@Composable
fun HelloWorldApp() {
  val context = LocalContext.current
  val focusManager = LocalFocusManager.current

  // State Management
  var name by remember { mutableStateOf("") }
  var currentGreetingIndex by remember { mutableStateOf(0) }
  var selectedTab by remember { mutableStateOf(0) }
  var profileInitials by remember { mutableStateOf("JD") }
  
  // Custom Greetings list using mutableStateListOf
  val greetingsList = remember { mutableStateListOf(*INITIAL_GREETINGS.toTypedArray()) }

  // Dialog states
  var showAddDialog by remember { mutableStateOf(false) }
  var showGuideDialog by remember { mutableStateOf(false) }

  // Active Greeting Calculation
  val activeGreeting = if (currentGreetingIndex in greetingsList.indices) {
    greetingsList[currentGreetingIndex]
  } else {
    greetingsList[0]
  }
  val displayName = name.trim().ifEmpty { "World" }
  val greetingText = activeGreeting.template.format(displayName)

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("hello_world_scaffold"),
    topBar = {
      // Custom Top App Bar (Height 16 = 64dp)
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(64.dp)
          .background(MaterialTheme.colorScheme.background)
          .padding(horizontal = 16.dp),
        contentAlignment = Alignment.CenterStart
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Menu,
              contentDescription = "Menu Icon",
              tint = MaterialTheme.colorScheme.onBackground,
              modifier = Modifier
                .size(24.dp)
                .clickable {
                  Toast.makeText(context, "Vibrant Palette Menu Opened", Toast.LENGTH_SHORT).show()
                }
            )
            Text(
              text = "Hello App",
              fontSize = 20.sp,
              fontWeight = FontWeight.Medium,
              color = MaterialTheme.colorScheme.onBackground
            )
          }

          // JD / VW Initials Avatar
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primary)
              .clickable {
                Toast.makeText(context, "Profile: $profileInitials", Toast.LENGTH_SHORT).show()
              },
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = profileInitials,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }
      }
    },
    bottomBar = {
      // Bottom Navigation Bar (Height 20 = 80dp)
      Column {
        // Subtle divider line
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(Color(0xFFC4C7CF))
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .background(Color(0xFFF3F4F9))
            .padding(bottom = 8.dp), // Safe margin at bottom
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          val navItems = listOf(
            Triple(0, "Home", Icons.Default.Home),
            Triple(1, "Search", Icons.Default.Search),
            Triple(2, "Updates", Icons.Default.Star),
            Triple(3, "Settings", Icons.Default.Settings)
          )

          navItems.forEach { (index, label, icon) ->
            val isSelected = selectedTab == index
            Column(
              modifier = Modifier
                .weight(1f)
                .clickable { selectedTab = index }
                .padding(vertical = 4.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
            ) {
              // Active pill container or simple icon space
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(16.dp))
                  .background(if (isSelected) Color(0xFFD1E4FF) else Color.Transparent)
                  .padding(horizontal = 20.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = icon,
                  contentDescription = label,
                  tint = if (isSelected) Color(0xFF001D36) else Color(0xFF44474F).copy(alpha = 0.6f),
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color(0xFF001D36) else Color(0xFF44474F).copy(alpha = 0.6f)
              )
            }
          }
        }
      }
    },
    floatingActionButton = {
      // FAB (Floating Action Button) - Shape: RoundedCornerShape(16.dp), Color: Teal
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = Color(0xFF386663),
        contentColor = Color.White,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .size(56.dp)
          .shadow(elevation = 8.dp, shape = RoundedCornerShape(16.dp))
          .testTag("fab_add_greeting")
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = "Add Custom Greeting",
          tint = Color.White,
          modifier = Modifier.size(24.dp)
        )
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(innerPadding)
    ) {
      // Cross-fade animation between tabs
      AnimatedContent(
        targetState = selectedTab,
        transitionSpec = {
          fadeIn(animationSpec = spring()) togetherWith fadeOut(animationSpec = spring())
        },
        label = "TabContentTransition"
      ) { targetTab ->
        Column(
          modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
          when (targetTab) {
            0 -> {
              // --- TAB 0: HOME ---
              // Upper sparkling subtitle
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Star,
                  contentDescription = "Decoration Star",
                  tint = Color(0xFF0061A4),
                  modifier = Modifier.size(16.dp)
                )
                Text(
                  text = "VIBRANT HELLO WORLD",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.SansSerif,
                  letterSpacing = 4.sp,
                  color = Color(0xFF0061A4)
                )
                Icon(
                  imageVector = Icons.Default.Star,
                  contentDescription = "Decoration Star",
                  tint = Color(0xFF0061A4),
                  modifier = Modifier.size(16.dp)
                )
              }

              // Beautiful Glass/Vibrant PrimaryContainer Greeting Card
              Card(
                shape = RoundedCornerShape(32.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                colors = CardDefaults.cardColors(
                  containerColor = Color(0xFFD1E4FF)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("greeting_card")
              ) {
                Column(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                  // Inner hand waving circle (96dp)
                  Box(
                    modifier = Modifier
                      .size(96.dp)
                      .clip(CircleShape)
                      .background(Color(0xFF0061A4)),
                    contentAlignment = Alignment.Center
                  ) {
                    Text(
                      text = "👋",
                      fontSize = 42.sp
                    )
                  }

                  // Slide and fade animation for language templates
                  AnimatedContent(
                    targetState = greetingText,
                    transitionSpec = {
                      (slideInVertically { height -> height } + fadeIn()) togetherWith
                              (slideOutVertically { height -> -height } + fadeOut())
                    },
                    label = "LanguageChangeAnimation"
                  ) { targetText ->
                    Text(
                      text = targetText,
                      fontSize = 36.sp,
                      fontWeight = FontWeight.SemiBold,
                      textAlign = TextAlign.Center,
                      color = Color(0xFF001D36),
                      lineHeight = 44.sp,
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("greeting_text")
                    )
                  }

                  // Cultural Language Badge
                  Box(
                    modifier = Modifier
                      .clip(CircleShape)
                      .background(Color(0xFF0061A4).copy(alpha = 0.12f))
                      .padding(horizontal = 14.dp, vertical = 6.dp)
                  ) {
                    Text(
                      text = "${activeGreeting.language} (${activeGreeting.nativeName})",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF001D36)
                    )
                  }

                  // Styled description text
                  Text(
                    text = "Welcome to your first app. Personalize it below by typing your name, or cycle languages with the primary button.",
                    fontSize = 14.sp,
                    color = Color(0xFF001D36).copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(horizontal = 8.dp)
                  )
                }
              }

              // Custom Name Input Textfield
              OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Enter your name") },
                placeholder = { Text("World") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                  imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                  onDone = { focusManager.clearFocus() }
                ),
                leadingIcon = {
                  Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Icon",
                    tint = Color(0xFF0061A4)
                  )
                },
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = Color(0xFF0061A4),
                  unfocusedBorderColor = Color(0xFF74777F),
                  focusedLabelColor = Color(0xFF0061A4),
                  unfocusedLabelColor = Color(0xFF44474F),
                  focusedContainerColor = Color.White,
                  unfocusedContainerColor = Color(0xFFF3F4F9),
                  focusedTextColor = Color(0xFF191C1E),
                  unfocusedTextColor = Color(0xFF191C1E),
                  cursorColor = Color(0xFF0061A4)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("name_input_field")
              )

              // Spacing helper
              Spacer(modifier = Modifier.height(4.dp))

              // Primary Action: Cycle Greeting (Say Hello Another Way)
              Button(
                onClick = {
                  currentGreetingIndex = (currentGreetingIndex + 1) % greetingsList.size
                },
                colors = ButtonDefaults.buttonColors(
                  containerColor = Color(0xFF0061A4),
                  contentColor = Color.White
                ),
                shape = CircleShape,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("cycle_greeting_button")
              ) {
                Row(
                  horizontalArrangement = Arrangement.Center,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Cycle Icon",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Say Hello Another Way",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                  )
                }
              }

              // Secondary Action: View Guide
              OutlinedButton(
                onClick = { showGuideDialog = true },
                colors = ButtonDefaults.outlinedButtonColors(
                  contentColor = Color(0xFF0061A4)
                ),
                border = BorderStroke(1.dp, Color(0xFF74777F)),
                shape = CircleShape,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("view_guide_button")
              ) {
                Text(
                  text = "View Guide",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Medium
                )
              }
            }

            1 -> {
              // --- TAB 1: EXPLORE & SEARCH ---
              Text(
                text = "Explore Greetings",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth()
              )
              
              var searchQuery by remember { mutableStateOf("") }
              
              OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search by language or native spelling") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF0061A4)) },
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = Color(0xFF0061A4),
                  unfocusedBorderColor = Color(0xFF74777F)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
              )

              val filteredList = greetingsList.filter {
                it.language.contains(searchQuery, ignoreCase = true) ||
                        it.nativeName.contains(searchQuery, ignoreCase = true)
              }

              if (filteredList.isEmpty()) {
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 48.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "No greetings match your search query.",
                    color = Color.Gray,
                    fontSize = 14.sp
                  )
                }
              } else {
                Column(
                  verticalArrangement = Arrangement.spacedBy(12.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  filteredList.forEach { item ->
                    val origIndex = greetingsList.indexOf(item)
                    Card(
                      colors = CardDefaults.cardColors(
                        containerColor = if (origIndex == currentGreetingIndex) Color(0xFFD1E4FF) else Color(0xFFF3F4F9)
                      ),
                      shape = RoundedCornerShape(16.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                          currentGreetingIndex = origIndex
                          selectedTab = 0
                          Toast.makeText(context, "Selected ${item.language}", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                      Row(
                        modifier = Modifier
                          .fillMaxWidth()
                          .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Column {
                          Text(
                            text = item.language,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF001D36)
                          )
                          Text(
                            text = item.template.format(displayName),
                            fontSize = 14.sp,
                            color = Color(0xFF001D36).copy(alpha = 0.7f)
                          )
                        }
                        Box(
                          modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF0061A4).copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                          Text(
                            text = item.nativeName,
                            fontSize = 12.sp,
                            color = Color(0xFF0061A4),
                            fontWeight = FontWeight.Bold
                          )
                        }
                      }
                    }
                  }
                }
              }
            }

            2 -> {
              // --- TAB 2: CULTURAL FACTS & UPDATES ---
              Text(
                text = "Greeting Fun Facts",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth()
              )

              Text(
                text = "Language is a gateway to cultures. Learn the origins and spiritual meanings of common greetings around the world.",
                fontSize = 14.sp,
                color = Color.Gray,
                modifier = Modifier.fillMaxWidth()
              )

              Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                GREETING_FACTS.forEach { fact ->
                  Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFDCECE9)), // Teal light secondary container
                    border = BorderStroke(1.dp, Color(0xFF386663).copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Column(
                      modifier = Modifier.padding(18.dp),
                      verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Text(
                          text = fact.language,
                          fontSize = 18.sp,
                          fontWeight = FontWeight.Bold,
                          color = Color(0xFF00201E)
                        )
                        Box(
                          modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF386663).copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                          Text(
                            text = fact.origin,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF386663)
                          )
                        }
                      }
                      Text(
                        text = fact.fact,
                        fontSize = 14.sp,
                        color = Color(0xFF00201E).copy(alpha = 0.8f),
                        lineHeight = 20.sp
                      )
                    }
                  }
                }
              }
            }

            3 -> {
              // --- TAB 3: SETTINGS ---
              Text(
                text = "App Settings",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth()
              )

              Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F4F9)),
                border = BorderStroke(1.dp, Color(0xFFC4C7CF)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(
                  modifier = Modifier.padding(20.dp),
                  verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                  // Profile Initial Customizer
                  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                      text = "Customize Profile Avatar Initials",
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onBackground
                    )
                    OutlinedTextField(
                      value = profileInitials,
                      onValueChange = { if (it.length <= 3) profileInitials = it.uppercase() },
                      singleLine = true,
                      colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF0061A4),
                        unfocusedBorderColor = Color(0xFF74777F)
                      ),
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.fillMaxWidth()
                    )
                  }

                  // Reset Custom Greetings
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = "Reset Greeting Database",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                      )
                      Text(
                        text = "Restore the initial 10 languages",
                        fontSize = 12.sp,
                        color = Color.Gray
                      )
                    }
                    Button(
                      onClick = {
                        greetingsList.clear()
                        greetingsList.addAll(INITIAL_GREETINGS)
                        currentGreetingIndex = 0
                        Toast.makeText(context, "Greetings Database Reset!", Toast.LENGTH_SHORT).show()
                      },
                      colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0061A4))
                    ) {
                      Text("Reset")
                    }
                  }

                  // Version/Brand Footer
                  Divider(color = Color(0xFFC4C7CF))
                  
                  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                      text = "Vibrant Palette Hello App v1.0",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      fontFamily = FontFamily.Monospace,
                      color = Color.Gray
                    )
                    Text(
                      text = "Designed with Google AI Studio",
                      fontSize = 11.sp,
                      fontFamily = FontFamily.Monospace,
                      color = Color.Gray
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // --- ADD GREETING DIALOG (FAB ACTION) ---
  if (showAddDialog) {
    var newLangName by remember { mutableStateOf("") }
    var newNativeName by remember { mutableStateOf("") }
    var newTemplate by remember { mutableStateOf("") }

    Dialog(onDismissRequest = { showAddDialog = false }) {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          Text(
            text = "Add Custom Language",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001D36)
          )

          OutlinedTextField(
            value = newLangName,
            onValueChange = { newLangName = it },
            label = { Text("Language Name (e.g. Swahili)") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = Color(0xFF0061A4),
              unfocusedBorderColor = Color(0xFF74777F)
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = newNativeName,
            onValueChange = { newNativeName = it },
            label = { Text("Native Name (e.g. Kiswahili)") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = Color(0xFF0061A4),
              unfocusedBorderColor = Color(0xFF74777F)
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = newTemplate,
            onValueChange = { newTemplate = it },
            label = { Text("Greeting Template (e.g. Jambo, %s!)") },
            placeholder = { Text("Must include %s for name placeholder") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = Color(0xFF0061A4),
              unfocusedBorderColor = Color(0xFF74777F)
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
          ) {
            TextButton(
              onClick = { showAddDialog = false },
              colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0061A4))
            ) {
              Text("Cancel")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                if (newLangName.isBlank() || newNativeName.isBlank() || newTemplate.isBlank()) {
                  Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                } else {
                  // Ensure %s exists in template
                  val verifiedTemplate = if (!newTemplate.contains("%s")) {
                    "$newTemplate %s"
                  } else {
                    newTemplate
                  }
                  greetingsList.add(GreetingLanguage(verifiedTemplate, newLangName, newNativeName))
                  currentGreetingIndex = greetingsList.size - 1
                  selectedTab = 0
                  showAddDialog = false
                  Toast.makeText(context, "Added $newLangName Successfully!", Toast.LENGTH_SHORT).show()
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0061A4))
            ) {
              Text("Add")
            }
          }
        }
      }
    }
  }

  // --- VIEW GUIDE DIALOG (SECONDARY ACTION) ---
  if (showGuideDialog) {
    Dialog(onDismissRequest = { showGuideDialog = false }) {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Info,
              contentDescription = "Info",
              tint = Color(0xFF0061A4),
              modifier = Modifier.size(24.dp)
            )
            Text(
              text = "Greeting App Guide",
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF001D36)
            )
          }

          Text(
            text = "Welcome to the Hello App! Here's how to make the most of it:\n\n" +
                    "1. 🌍 **Translate**: Tap 'Say Hello Another Way' to cycle through different global languages.\n\n" +
                    "2. ✍️ **Personalize**: Enter your name in the text field to see the greeting update dynamically.\n\n" +
                    "3. ➕ **Add Custom**: Click the Teal '+' FAB in the bottom right corner to insert your own language and custom templates!\n\n" +
                    "4. 🔍 **Search & Fun Facts**: Use the Bottom Navigation Bar tabs to explore or learn historical origins.",
            fontSize = 14.sp,
            color = Color(0xFF001D36).copy(alpha = 0.8f),
            lineHeight = 22.sp
          )

          Button(
            onClick = { showGuideDialog = false },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0061A4)),
            modifier = Modifier.align(Alignment.End)
          ) {
            Text("Got it")
          }
        }
      }
    }
  }
}

@Preview(showBackground = true)
@Composable
fun HelloWorldAppPreview() {
  MyApplicationTheme {
    HelloWorldApp()
  }
}
